# Edmonton Oilers Digital Infrastructure Analysis

## Current Technology Stack

### Arena Technology Infrastructure
- **Cisco-based Converged Network**: Implemented by Long View Systems for Rogers Place, providing the foundation for the arena's digital capabilities
- **VoIP Phone System**: Integrated communications system throughout Rogers Place
- **Digital Signage**: Extensive digital display network throughout the arena for fan engagement and advertising

### Fan Engagement Platforms
- **Oilers+ Streaming Platform**: 
  - Powered by LiveU technology (LU800 field unit and LU300S field encoder)
  - Provides exclusive behind-the-scenes content, live shows, pre/post-game shows, press conferences
  - Subscription-based model ($12/month) that grew from 10,000 to 20,000+ subscribers in two years
  - Generated over $1M in revenue in second year of operation
  - Managed by Ryan Hyrcun, Manager of Video Production

### Ticketing & Access Systems
- **Ticketmaster**: Primary ticketing platform with Account Manager functionality
- **Digital Wallet Integration**: Support for Apple Wallet and Google Wallet
- **Mobile App Ecosystem**:
  - Rogers Place App: Arena-specific features and ticket management
  - NHL App: League-wide content and ticket integration
  - Ticketmaster App: Ticket management and transfers

### Data & Analytics
- **Data Analytics Team**: Led by Michael Parkatti (Data & Analytics Leader)
- **Unknown CRM System**: Evidence of CRM integration with revenue management, but specific platform not identified

### Video Production
- **Remote Production Workflow**: LiveU-powered remote production capabilities for home and away games
- **Production Control Room**: Located at Rogers Place in Edmonton
- **Content Creation Infrastructure**: Supports 82-game season content production for social media and OTT platform

## Key Decision Makers

### Executive Leadership
- **Jeff Jackson**: CEO of Hockey Operations (appointed August 2023)
- **Jürgen Schreiber**: CEO, OEG Inc. (Oilers Entertainment Group)
- **Paul Marcaccio**: CFO, OEG Inc.
- **Vivian Wagner**: SVP, Business Operations for ICE District (appointed October 2024)

### Technology & Digital Leadership
- **Ryan Hyrcun**: Manager of Video Production
- **Michael Parkatti**: Data & Analytics Leader

### Business Operations
- **Kevin Radomski**: Director, Business Operations and Alternate Governor, Edmonton Oil Kings Hockey Club

## Technology Implementation Timeline
- **2015**: Long View Systems implemented Cisco-based converged network and VoIP system for Rogers Place
- **2023**: Implemented LiveU technology for Oilers+ streaming platform
- **2024**: Enhanced digital ticketing security measures with digital wallet requirements
