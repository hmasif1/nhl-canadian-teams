# Winnipeg Jets Digital Infrastructure Analysis

## Current Technology Stack & Digital Infrastructure

The Winnipeg Jets and their parent company True North Sports + Entertainment have made significant investments in their digital infrastructure and fan experience technologies. Their current technology stack includes:

1. **Customer Data Platform (CDP)**: Partnership with StellarAlgo since 2021 to unlock insights within their customer databases, enabling better identification of engagement opportunities, content personalization across channels, and fan response feedback. This platform helps True North properties better understand and engage with their fans and customers.

2. **Mobile Ticketing Platform**: Partnership with Pogoseat to power both Last-Minute and Student Rush ticket programs. This platform enables a smooth and user-friendly mobile ticketing experience, allowing fans to access tickets via text message rather than through traditional ticketing processes.

3. **Wi-Fi Infrastructure**: Implementation of Extreme Networks' Wi-Fi 6 and Wi-Fi 6E solutions at Canada Life Centre, featuring nearly 800 access points. This advanced network supports mobile tickets, social media, online sports betting applications, and mobile concessions.

4. **Analytics Platform**: Utilization of ExtremeAnalytics to analyze network usage data, focusing on popular applications, high-traffic areas, and peak user activity moments within the arena. These insights help the Jets make informed decisions about resource allocation, marketing partnerships, and between-play programming.

5. **Real-Time Audio Streaming**: Partnership with ProWire to deliver in-game commentary and specialty Jets' original broadcasts, including TSN and CJOB, in real-time through fans' mobile devices. This fully integrated service runs on the venue's WiFi network and is accessible via the NHL app.

6. **AI-Based Security Screening**: Implementation of a contactless security screening system that uses AI technology to significantly reduce wait times for guests entering Canada Life Centre. This system allows fans to walk through security without removing items from pockets and bags.

7. **Sound System**: Recent $2-million upgrade to the arena's sound system to provide an enhanced audio experience for all Canada Life Centre events.

8. **Mobile App & Rewards Program**: The Official Winnipeg Jets App provides game information, schedules, roster details, team news, and ticket management. The Jets 360 Rewards program allows fans to play games, enter contests, and earn rewards.

9. **Ice Projection System**: Advanced on-ice projection system featuring eight laser projectors that transform the ice at Canada Life Centre into a massive display screen for enhanced pre-game shows and fan experiences.

10. **Digital Engagement Tools**: "Jet Stream" promotion allowing fans to submit songs for game playlists through the team's social channels.

## Key Technology Decision Makers

1. **Tyler Kurz** - Vice President, Business Intelligence at True North Sports + Entertainment
   * Responsible for data analytics and business intelligence initiatives
   * Key decision maker for the StellarAlgo CDP implementation
   * Focused on transforming how the Jets connect with fans through data

2. **Christina Litz** - Chief Brand and Commercial Officer at True North Sports + Entertainment
   * Oversees brand strategy, commercial partnerships, and fan experience initiatives
   * Key decision maker for ProWire implementation and other fan experience technologies
   * Focused on creating unique fan experiences at Canada Life Centre

3. **Dawn Haus** - SVP of Culture & Guest Experience for True North Sports & Entertainment
   * Responsible for overall guest experience and venue operations
   * Key decision maker for the AI-based security screening system
   * Focused on improving operational efficiency and enhancing fan satisfaction

## Technology Implementation Timeline

* July 2021: Partnership with StellarAlgo for Customer Data Platform
* October 2021: Partnership with ProWire for real-time audio streaming
* September 2021: Implementation of new on-ice projection system
* November 2023: Deployment of Extreme Networks Wi-Fi 6 and Wi-Fi 6E solutions
* October 2024: Implementation of AI-based security screening system
* October 2024: Completion of $2-million sound system upgrade
