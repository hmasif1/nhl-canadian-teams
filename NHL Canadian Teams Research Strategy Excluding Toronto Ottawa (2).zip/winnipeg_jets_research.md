# Winnipeg Jets Research

## Basic Information
- Founded: 1999 (as Atlanta Thrashers, relocated to Winnipeg in 2011)
- Arena: Canada Life Centre
- Location: Winnipeg, Manitoba
- Team Colors: Polar night blue, aviator blue, silver, and white
- Stanley Cup Championships: 0
- Website: https://www.nhl.com/jets

## Business Operations & Technology Infrastructure

### Leadership Structure
- Key Leadership:
  - Tyler Kurz - VP of Business Intelligence at True North Sports + Entertainment
  - Andrew Wilkinson - Director of Digital Strategy and Products for True North Sports + Entertainment
  - Larry Simmons - VP & Assistant General Manager

### Arena Technology (Canada Life Centre)
- Advanced Wi-Fi infrastructure featuring Wi-Fi 6 and Wi-Fi 6E access points
- Extreme Universal Switches for network management
- ExtremeAnalytics for network usage data analysis
- Assistive listening devices available at hockey games
- Digital ticketing system integrated with mobile app

### Digital Fan Engagement
- Jets 360 Rewards Program:
  - Launched in October 2022 alongside new mobile app
  - Free rewards program allowing fans to complete challenges and earn "pucks"
  - Nine team, arena, and community-based challenges
  - Increased fan engagement by 245% within first months
  - 45,000 app downloads in first three months (exceeding first-year goal)
  - 30,000 Jets app users opted into Jets 360 program
  - 75% of Jets 360 members are casual fans (not season ticket holders)
  - QR code system for tracking individual fan data and behavior

- Mobile App Development:
  - Partnership with Mirego (Canadian-based Digital Strategy and Development firm)
  - Features include:
    - Digital ticketing
    - Real-time updates
    - Live scores
    - Player statistics
    - Interactive games and challenges
    - Arena information

### Data Analytics and Customer Insights
- Partnership with StellarAlgo for Customer Data Platform (CDP)
  - Consolidates customer data into a single customer view
  - Enables personalized marketing in near real-time
  - Machine-learning technology for predictive capabilities
  - Helps identify opportunities to drive engagement
  - Personalizes content across different channels
  - Provides sales team with valuable customer information
  - Streamlines segmentation and attribution processes

### Security Technology
- AI-powered weapon screening system for home games
- Enhanced security protocols at Canada Life Centre

### True North Sports + Entertainment Properties
- Winnipeg Jets (NHL)
- Manitoba Moose (AHL)
- Canada Life Centre
- Bell MTS Iceplex
- Burton Cummings Theatre
- True North Square (1.5-million-square-foot, 5-tower mixed-use development)

## Business Opportunities for OSF DIGITAL

### CRM and Fan Engagement Enhancement
- Opportunity to integrate Jets 360 rewards program with Salesforce
- Potential to enhance gamification elements with Salesforce Experience Cloud
- Opportunity to create a unified fan profile across all True North properties

### Mobile App Enhancement
- Potential to implement Salesforce Mobile SDK for enhanced app functionality
- Opportunity to integrate mobile app with Marketing Cloud for personalized messaging
- Potential to enhance QR code system with Salesforce-powered analytics

### Data Analytics Integration
- Opportunity to complement StellarAlgo CDP with Salesforce Einstein Analytics
- Potential to enhance predictive capabilities with agentforce solutions
- Opportunity to create a comprehensive view of fan behavior across digital and physical touchpoints

### Wi-Fi and Network Infrastructure Enhancement
- Potential to leverage Extreme Networks partnership with Salesforce integration
- Opportunity to enhance ExtremeAnalytics with Salesforce dashboards
- Potential to implement real-time fan engagement based on network activity

### Multi-Property Integration
- Opportunity to create a unified customer experience across all True North properties
- Potential to implement Salesforce Service Cloud for venue operations
- Opportunity to enhance cross-selling between properties with Salesforce Commerce Cloud

## Key Decision Makers to Target
- Tyler Kurz - VP of Business Intelligence at True North Sports + Entertainment
- Andrew Wilkinson - Director of Digital Strategy and Products for True North Sports + Entertainment
- Director of IT (to be identified)
- Director of Fan Experience (to be identified)
- Director of Venue Operations (to be identified)
