# Canadian NHL Teams (Excluding Toronto and Ottawa)

## 1. Montreal Canadiens
- Founded: 1909
- Arena: Bell Centre
- Location: Montreal, Quebec
- Team Colors: Red, white, and blue
- Stanley Cup Championships: 24 (most in NHL history)
- Website: https://www.nhl.com/canadiens

## 2. Vancouver Canucks
- Founded: 1970
- Arena: Rogers Arena
- Location: Vancouver, British Columbia
- Team Colors: Blue, green, and white
- Stanley Cup Championships: 0 (Finals appearances in 1982, 1994, 2011)
- Website: https://www.nhl.com/canucks

## 3. Edmonton Oilers
- Founded: 1972 (joined NHL in 1979)
- Arena: Rogers Place
- Location: Edmonton, Alberta
- Team Colors: Orange, navy blue, and white
- Stanley Cup Championships: 5 (1984, 1985, 1987, 1988, 1990)
- Website: https://www.nhl.com/oilers

## 4. Calgary Flames
- Founded: 1972 (as Atlanta Flames, relocated to Calgary in 1980)
- Arena: Scotiabank Saddledome
- Location: Calgary, Alberta
- Team Colors: Red, yellow, and black
- Stanley Cup Championships: 1 (1989)
- Website: https://www.nhl.com/flames

## 5. Winnipeg Jets
- Founded: 2011 (relocated from Atlanta Thrashers)
- Arena: Canada Life Centre
- Location: Winnipeg, Manitoba
- Team Colors: Navy blue, silver, and white
- Stanley Cup Championships: 0
- Website: https://www.nhl.com/jets
