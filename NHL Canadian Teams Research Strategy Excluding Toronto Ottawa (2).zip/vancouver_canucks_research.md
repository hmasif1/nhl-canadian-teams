# Vancouver Canucks Research

## Basic Information
- Founded: 1970
- Arena: Rogers Arena
- Location: Vancouver, British Columbia
- Team Colors: Blue, green, and white
- Stanley Cup Championships: 0 (Finals appearances in 1982, 1994, 2011)
- Website: https://www.nhl.com/canucks

## Business Operations & Technology Infrastructure

### Digital Infrastructure and Cybersecurity
- Partnership with Fortinet as "Preferred Partner" for cybersecurity solutions
- Implementation of Fortinet Security Fabric platform and Secure SD-WAN
- Central FortiGate Next-Generation Firewall (NGFW) cluster at data center
- Single pane of glass to consolidate management, visibility, analytics, and control
- Secure communications between multiple locations (Rogers Arena, training facilities, eSports team)

### Digital Transformation at Rogers Arena
- Partnership with Creative Realities for digital signage and IPTV solutions
- Deployment of over 900 digital displays powered by Uniguest's Tripleplay IPTV and Digital Signage solution
- LG Electronics Canada high-definition screens throughout the venue
- New digital infrastructure supporting over 900 endpoints with IPTV network connectivity
- Advanced content strategy featuring POS-integrated digital menu boards
- "Moments of Exclusivity Triggers" allowing synchronization of all screens during key moments
- High-end hospitality approach leveraging digital content for premium offerings
- Phased implementation with Phase One completed and Phase Two in planning

### Fan Engagement and CRM
- Partnership with Rival Technologies for fan insights and engagement
- Built an insight community of 5000+ fans recruited exclusively via social media
- 33% response rate in just 6 minutes for conversational surveys
- 85% of community members are under 40; 74% are male
- Use of conversational surveys to measure ticket purchase drivers and sponsor recall
- Partnership with FanReach for mobile platform upgrades
- Implementation of targeted and personalized marketing elements
- Partnership with StellarAlgo for fan avidity modeling to improve engagement and conversion

### Management Structure
- Key Leadership:
  - Nguyen Nguyen - Senior VP of Technology at Canucks Sports & Entertainment
  - Brad Pennefather - Former VP of Membership and Business Intelligence
  - Kevin Kinghorn - Digital Marketing Leader (role to be confirmed)

## Business Opportunities for OSF DIGITAL

### CRM and Fan Engagement Enhancement
- Current fan insight community could benefit from integration with Salesforce Marketing Cloud
- Opportunity to enhance personalization capabilities through Salesforce Einstein Analytics
- Potential to implement AI-driven fan engagement strategies to improve the 33% response rate

### Digital Signage and Content Management
- Opportunity to integrate the 900+ digital displays with Salesforce CRM for personalized messaging
- Potential to enhance "Moments of Exclusivity Triggers" with Salesforce Marketing Cloud
- Opportunity to implement agentforce solutions for content management and distribution

### Data Analytics and Fan Insights
- Opportunity to enhance their fan avidity model with Salesforce Einstein Analytics
- Need for robust data integration between various systems (ticketing, merchandise, concessions, etc.)
- Potential for predictive analytics to improve fan retention and revenue generation

### E-commerce and Merchandising
- Opportunity to enhance mobile ordering system with Salesforce Commerce Cloud
- Potential to create a seamless omnichannel experience across in-arena, online, and mobile shopping

### Cybersecurity and IT Operations
- Potential to complement Fortinet security solutions with Salesforce Shield for data security
- Opportunity to implement Salesforce Service Cloud for IT service management
- Potential to enhance network monitoring and management with agentforce solutions

## Key Decision Makers to Target
- Nguyen Nguyen - Senior VP of Technology
- Current VP of Membership and Business Intelligence (successor to Brad Pennefather)
- Director of Digital Marketing (to be identified)
- Director of Fan Experience (to be identified)
- IT Security Director (to be identified)
