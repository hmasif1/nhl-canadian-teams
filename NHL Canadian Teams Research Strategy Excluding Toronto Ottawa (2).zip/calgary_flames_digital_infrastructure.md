# Calgary Flames Digital Infrastructure Analysis

## Current Technology Stack

### Fan Engagement Platforms
- **FanReach Mobile App**: 
  - Launched in September 2023
  - Features include real-time updates, live scores, player statistics, ticket management, 50/50 draws, and venue information
  - Designed as a "one-stop-shop" for all team-related information
  - Presented by Scotiabank
  - Part of a broader initiative by Calgary Sports and Entertainment Corporation (CSEC) to launch dedicated apps for all their sports franchises

### Arena Technology Infrastructure
- **Amazon Just Walk Out Technology**:
  - Implemented in September 2023 at Scotiabank Saddledome
  - First Canadian venue to introduce this technology
  - Located on the main concourse
  - Uses AI, computer vision, and deep learning to automatically detect items taken from store shelves
  - Eliminates checkout lines for concessions
  - Customers use credit/debit cards at entrance gates and are automatically charged for items taken

### Cybersecurity & Data Management
- **Acronis Partnership**:
  - Announced in May 2024
  - Provides data backup and cybersecurity solutions
  - Supported by Expera Information Technology Inc. as the CyberFit Partner
  - Focuses on data protection and cyber threat prevention

### Future Technology Infrastructure (Scotia Place - Opening 2027)
- **Sustainability Technology**:
  - 600 solar panels for on-site power generation
  - Connection to District Energy Centre
  - Designed to be fully electrified and net-zero by 2050
- **Digital Displays**:
  - 140-meter digital display (reportedly the longest in North America)
- **Venue Technology**:
  - Flexible configuration capabilities for different event types
  - Enhanced accessibility features including elevators and escalators
  - Improved roof load capacity (400,000 tons vs. 90,000 tons at Saddledome)
  - Adaptive bathroom facilities that can be reconfigured based on event demographics
  - 20% more bathrooms than Rogers Place in Edmonton

## Key Decision Makers

### Executive Leadership
- **John Bean**: Vice Chairman (former President & CEO)
- **Robert Hayes**: President & CEO (appointed May 2024)
- **Lorenzo DeCicco**: Chief Operating Officer
- **Paul Kong**: Chief Financial Officer

### Technology & Operations Leadership
- **Ziad Mehio**: VP of Technology and Food & Beverage
- **Susie Darrington**: VP of Building Operations, Scotia Place Project Committee Member
- **Bob Hunter**: Project Director for Scotia Place

## Technology Implementation Timeline
- **September 2023**: Launched FanReach mobile app
- **September 2023**: Implemented Amazon's Just Walk Out technology at Scotiabank Saddledome
- **May 2024**: Announced partnership with Acronis for cybersecurity and data backup
- **December 2024**: Development permit approved for Scotia Place with advanced technology features
- **Fall 2027**: Projected opening of Scotia Place arena
