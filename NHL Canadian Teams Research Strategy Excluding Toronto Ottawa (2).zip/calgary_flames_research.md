# Calgary Flames Research

## Basic Information
- Founded: 1972 (as Atlanta Flames, relocated to Calgary in 1980)
- Arena: Scotiabank Saddledome (New arena "Scotia Place" planned for 2027-28 season)
- Location: Calgary, Alberta
- Team Colors: Red, yellow, and black
- Stanley Cup Championships: 1 (1989)
- Website: https://www.nhl.com/flames

## Business Operations & Technology Infrastructure

### Leadership Structure
- Key Leadership:
  - Kevin Gross - VP of Partnership Sales and Broadcast at Calgary Sports and Entertainment Corporation
  - Ziad Mehio - VP of Technology at Calgary Sports and Entertainment
  - Vince Fung - Founder & CEO of Expera IT (technology partner)

### Current Arena Technology (Scotiabank Saddledome)
- New Sportsnet Scoreboard installed for 2024-25 season
  - Includes upper LED halo ring with 40' circumference for partnership and fan experience elements
- Amazon's Just Walk Out technology implemented in 2023
  - Allows fans to grab food and beverages without checkout lines
  - First Canadian arena to implement this technology
- Wi-Fi connectivity throughout the venue
- Digital signage and displays

### Digital Fan Engagement
- Partnership with FanReach for mobile app development
  - Launched new Calgary Flames and Calgary Wranglers team app in 2023
  - Features include:
    - Real-time updates on team news
    - Live scores during games
    - Detailed player statistics
    - Ticket management
    - 50/50 draws directly from mobile device
    - Interactive games and challenges
    - Scotiabank Saddledome venue information
- Plans to launch dedicated team apps for each CSEC sports franchise (Calgary Hitmen, Calgary Roughnecks, Calgary Stampeders)

### Technology Partnerships
- Acronis and Expera IT partnership for cybersecurity
  - Provides comprehensive security solutions for diverse and distributed IT environments
  - Expera IT serves as the official Acronis #CyberFit Partner
- ESET Canada extended partnership for cybersecurity solutions
- Microsoft partnership for Windows 11 Pro implementation
  - Focuses on enhancing fan experience through technology

### New Arena Development (Scotia Place)
- Scheduled to open for the 2027-28 NHL season
- $800 million investment
- Technology features will include:
  - Interactive fan experiences
  - LED lighting and advanced audio-visual systems
  - 140-metre digital display (believed to be the longest in Canada)
  - Eco-friendly materials and energy-efficient systems
  - Renewable energy sources
  - Reduced water consumption and waste management systems
  - Modern technology for energy-efficient heating, cooling, and lighting

## Business Opportunities for OSF DIGITAL

### CRM and Fan Engagement Enhancement
- Opportunity to enhance the FanReach-developed mobile app with Salesforce integration
- Potential to implement AI-driven content recommendations and personalization
- Opportunity to create a unified fan profile across ticketing, merchandise, and digital platforms

### Arena Technology Integration
- Potential to integrate Amazon's Just Walk Out technology with Salesforce for customer insights
- Opportunity to enhance digital signage with Salesforce Marketing Cloud for personalized messaging
- Potential to implement Salesforce Service Cloud for arena operations management

### New Arena Technology Planning
- Strategic opportunity to be involved in Scotia Place technology planning (2025-2027)
- Potential to implement Salesforce solutions from the ground up in the new arena
- Opportunity to create a comprehensive digital strategy for the new venue

### Data Analytics and Fan Insights
- Opportunity to implement Salesforce Einstein Analytics to derive insights from mobile app usage
- Potential to create predictive models for ticket sales and merchandise purchases
- Opportunity to enhance revenue generation through targeted promotions

### Cybersecurity Enhancement
- Potential to complement Acronis and ESET security solutions with Salesforce Shield
- Opportunity to implement comprehensive data protection strategies
- Potential to enhance security operations with agentforce solutions

## Key Decision Makers to Target
- Kevin Gross - VP of Partnership Sales and Broadcast
- Ziad Mehio - VP of Technology
- Director of Fan Experience (to be identified)
- Director of IT Security (to be identified)
- New Arena Technology Planning Team (to be identified)
