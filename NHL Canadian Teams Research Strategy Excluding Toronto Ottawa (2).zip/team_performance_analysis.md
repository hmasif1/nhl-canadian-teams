# NHL Canadian Teams Performance Analysis

## Current Standings and Performance (as of March 30, 2025)

### Winnipeg Jets
- **Current Standing**: 1st in Central Division, Western Conference
- **Record**: 51-19-4 (106 points)
- **Performance Highlights**: 
  - Clinched playoff berth
  - +83 goal differential (best among Canadian teams)
  - 28-6-4 home record
  - 7-3-0 in last 10 games
- **Top Performers**:
  - Kyle Connor: 88 points (37 goals, 51 assists)
  - Mark Scheifele: 80 points (36 goals, 44 assists)
  - Nikolaj Ehlers: 62 points (24 goals, 38 assists)

### Edmonton Oilers
- **Current Standing**: 3rd in Pacific Division, Western Conference
- **Record**: 42-26-5 (89 points)
- **Performance Highlights**:
  - +21 goal differential
  - 23-12-3 home record
  - 5-4-1 in last 10 games
- **Top Performers**:
  - Leon Draisaitl: 104 points (51 goals, 53 assists)
  - Connor McDavid: 90 points (26 goals, 64 assists)
  - Evan Bouchard: 58 points (13 goals, 45 assists)

### Vancouver Canucks
- **Current Standing**: 3rd in Wild Card race, Western Conference
- **Record**: 34-27-13 (81 points)
- **Performance Highlights**:
  - -16 goal differential
  - 15-13-7 home record
  - 5-3-2 in last 10 games
- **Top Performers**:
  - Quinn Hughes: 70 points (16 goals, 54 assists)
  - Brock Boeser: 46 points (24 goals, 22 assists)
  - Elias Pettersson: 45 points (15 goals, 30 assists)

### Calgary Flames
- **Current Standing**: 4th in Wild Card race, Western Conference
- **Record**: 34-26-12 (80 points)
- **Performance Highlights**:
  - -24 goal differential
  - 19-12-5 home record
  - 5-3-2 in last 10 games
- **Top Performers**:
  - Nazem Kadri: 58 points (30 goals, 28 assists)
  - Jonathan Huberdeau: 58 points (27 goals, 31 assists)
  - MacKenzie Weegar: 41 points (7 goals, 34 assists)

### Montreal Canadiens
- **Current Standing**: 2nd in Wild Card race, Eastern Conference
- **Record**: 34-30-9 (77 points)
- **Performance Highlights**:
  - -26 goal differential
  - 18-12-5 home record
  - 4-3-3 in last 10 games
- **Top Performers**:
  - Nick Suzuki: 77 points (23 goals, 54 assists)
  - Cole Caufield: 63 points (34 goals, 29 assists)
  - Lane Hutson: 59 points (5 goals, 54 assists)

## Performance Comparison

### Strongest Performing Teams
1. **Winnipeg Jets** - Leading the Central Division with 106 points, they have the best record among Canadian teams and have already clinched a playoff spot. Their +83 goal differential demonstrates their dominance.

2. **Edmonton Oilers** - With 89 points and in 3rd place in the Pacific Division, they are likely to make the playoffs. They have the highest-scoring player among Canadian teams (Leon Draisaitl with 104 points).

### Teams on the Bubble
3. **Vancouver Canucks** - With 81 points, they are competing for a Wild Card spot in the Western Conference.

4. **Calgary Flames** - Close behind with 80 points, they are also in the Wild Card race in the Western Conference.

5. **Montreal Canadiens** - Currently holding a Wild Card position in the Eastern Conference with 77 points, but their negative goal differential suggests they may struggle to maintain this position.

## Business Implications

### High-Performing Teams (Winnipeg, Edmonton)
- These teams have strong fan engagement due to their success
- Likely to have playoff revenue streams
- Potential for increased merchandise sales and sponsorship opportunities
- Higher visibility for technology partnerships

### Teams on the Bubble (Vancouver, Calgary, Montreal)
- Fan engagement may be more volatile based on performance
- Need for enhanced fan experiences to maintain interest regardless of on-ice results
- Opportunity for technology solutions that help drive attendance and engagement
- May be more open to innovative approaches to increase revenue streams

## Prospecting Priorities
Based on performance analysis, the recommended priority order for OSF DIGITAL prospecting efforts:

1. **Winnipeg Jets** - Their success and playoff berth make them an attractive partner with potentially more resources for technology investments.

2. **Edmonton Oilers** - Strong performance and star power (McDavid, Draisaitl) create significant opportunities for fan engagement solutions.

3. **Montreal Canadiens** - Despite mixed performance, they have a large, dedicated fanbase and are in a major market.

4. **Vancouver Canucks** - Their competitive position in the standings and market size make them a good prospect.

5. **Calgary Flames** - With their new arena development (Scotia Place) planned for 2027-28, they may be more focused on physical infrastructure than digital transformation in the short term.
