# Edmonton Oilers Key Decision Makers for Salesforce & Agentforce Implementation

## Executive Leadership

### Jürgen Schreiber
**Title:** CEO, OEG Inc. (Oilers Entertainment Group)
**Role:** Ultimate business decision maker with final approval authority for major technology investments
**Focus Areas:** Overall business strategy, revenue growth, operational efficiency
**Background:** Leads the Oilers Entertainment Group, overseeing all business operations including technology strategy
**Influence Level:** Executive Sponsor (High)

### Paul Marcaccio
**Title:** CFO, OEG Inc.
**Role:** Financial decision maker responsible for budget approval and ROI assessment
**Focus Areas:** Investment returns, cost management, financial performance
**Background:** Oversees financial operations for the Oilers Entertainment Group
**Influence Level:** Financial Approver (High)

### Vivian Wagner
**Title:** SVP, Business Operations for ICE District
**Role:** Senior leader responsible for business operations and customer experience
**Focus Areas:** Operational efficiency, customer experience, business process optimization
**Background:** Recently appointed (October 2024) with nearly two decades of experience in hospitality
**Influence Level:** Business Stakeholder (Medium-High)

## Technology Leadership

### [Chief Technology Officer / CIO]
**Note:** Research did not reveal a specific CTO or CIO by name, but this role likely exists within the organization
**Role:** Primary technology decision maker responsible for technology strategy and implementation
**Focus Areas:** Technology infrastructure, digital transformation, vendor selection
**Influence Level:** Technical Decision Maker (High)

### Michael Parkatti
**Title:** Data & Analytics Leader
**Role:** Responsible for data strategy and analytics capabilities
**Focus Areas:** Data integration, analytics, business intelligence
**Background:** Data science background with focus on analytics implementation
**Influence Level:** Technical Influencer (Medium-High)

## Digital & Content Leadership

### Ryan Hyrcun
**Title:** Manager of Video Production
**Role:** Leads digital content creation and distribution through Oilers+ platform
**Focus Areas:** Content production, streaming technology, fan engagement
**Background:** Long-time believer in digital media who launched the Oilers+ streaming platform
**Influence Level:** Digital Stakeholder (Medium)

## Business Operations Leadership

### Kevin Radomski
**Title:** Director, Business Operations and Alternate Governor, Edmonton Oil Kings Hockey Club
**Role:** Oversees business operations for the Oil Kings (WHL team owned by OEG)
**Focus Areas:** Operational efficiency, customer experience, revenue generation
**Background:** Experience in hockey operations and business management
**Influence Level:** Business Stakeholder (Medium)

## Marketing & Fan Engagement Leadership

### [VP of Marketing / Fan Experience]
**Note:** Research did not reveal a specific marketing leader by name, but this role likely exists
**Role:** Responsible for marketing strategy and fan experience initiatives
**Focus Areas:** Fan engagement, brand management, digital marketing
**Influence Level:** Marketing Stakeholder (Medium-High)

## Target Decision Makers for Salesforce & Agentforce Implementation

Based on the research, the following individuals should be prioritized for personalized outreach regarding Salesforce and agentforce implementations:

### Primary Targets

1. **Jürgen Schreiber (CEO, OEG Inc.)**
   - Executive sponsor with ultimate decision-making authority
   - Focus messaging on business impact, revenue growth, and competitive advantage

2. **[Chief Technology Officer / CIO]**
   - Primary technical decision maker
   - Focus messaging on technical capabilities, integration with existing systems, and implementation approach

3. **Michael Parkatti (Data & Analytics Leader)**
   - Key technical influencer for data-related aspects
   - Focus messaging on data unification, analytics capabilities, and AI-powered insights

### Secondary Targets

4. **Paul Marcaccio (CFO, OEG Inc.)**
   - Financial approver
   - Focus messaging on ROI, cost savings, and financial benefits

5. **Vivian Wagner (SVP, Business Operations)**
   - Business operations stakeholder
   - Focus messaging on operational efficiency, process improvement, and customer experience

6. **Ryan Hyrcun (Manager of Video Production)**
   - Digital content stakeholder
   - Focus messaging on content personalization, distribution efficiency, and fan engagement

### Decision-Making Dynamics

The decision-making process for a major technology implementation like Salesforce and agentforce would likely follow this path:

1. **Initial Interest:** Generated through outreach to technical stakeholders like Michael Parkatti or the CTO
2. **Technical Evaluation:** Led by the CTO with input from Michael Parkatti and Ryan Hyrcun
3. **Business Case Development:** Involving Vivian Wagner and Paul Marcaccio
4. **Final Approval:** Ultimate decision made by Jürgen Schreiber as CEO

A successful engagement strategy should target multiple stakeholders simultaneously, recognizing their different priorities and concerns while presenting a unified vision for how Salesforce and agentforce can transform the Oilers' digital capabilities.
