# Vancouver Canucks Digital Infrastructure Analysis

## Current Technology Stack

### Digital Signage & In-Arena Experience
- **Creative Realities Partnership** (March 2025)
  - Over 900 digital displays powered by Uniguest's Tripleplay IPTV and Digital Signage solution
  - POS-integrated digital menu boards for food and beverage sales optimization
  - Moments of Exclusivity Triggers for synchronized screen content during key moments
  - LG Electronics Canada high-definition screens throughout Rogers Arena

### Cybersecurity Infrastructure
- **Fortinet Partnership** (December 2024)
  - "Security fabric" platform for simplified detection and response to cyberattacks
  - FortiGate Next-Generation Firewall cluster at Canucks data center
  - Software-defined wide-area-network (SD-WAN) implementation in progress
  - Protection for physical central data center, Rogers Arena, training facilities

### Cloud Storage & Media Management
- **Wasabi Technologies Partnership** (March 2024)
  - Hot cloud storage for digital operations via multi-year technology deal
  - AI capabilities for searching and indexing video archives (Curio AI from GrayMeta)
  - No fees for egress or API calls, allowing real-time data access
  - Used for storing and managing media content

### Fan Engagement & Research
- **Rival Technologies Platform**
  - 5,000-fan insight community for real-time feedback
  - Mobile-first conversational research platform
  - Measures sponsor recall and campaign effectiveness
  - Provides actionable feedback for fan experience improvements

### Mobile Application
- **FanReach Mobile Platform** (March 2021)
  - Live audio streaming capabilities
  - Integrated sponsorship opportunities
  - Personalized marketing elements
  - Event-based data tracking for business analysis
  - Programmatic partner system for excess advertising inventory

### Customer Data Platform
- **StellarAlgo CDP** (May 2020)
  - Unifies over ten customer data systems including Ticketmaster ticketing data
  - Grew marketable universe by over 40%
  - Fan avidity model to improve engagement across fan segments
  - Automated insights for non-technical staff
  - Increased engagement by 37% across all fan touchpoints
  - Improved ROI seven times from target fan groups

### CRM System
- **Microsoft Dynamics** (implemented circa 2013)
  - Used for sales and sponsorship management
  - Customer data management for fan relationships
  - Integration with other business systems

### Key Technology Decision Makers
- **Nguyen Nguyen** - Sr. Vice President of Technology, Canucks Sports & Entertainment, Aquilini Group
- **Kevin Kinghorn** - Vice President of Marketing, Vancouver Canucks
- **Terry Kalna** - Chief Revenue Officer, Canucks Sports & Entertainment
