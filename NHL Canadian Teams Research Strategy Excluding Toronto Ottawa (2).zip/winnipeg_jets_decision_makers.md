# Winnipeg Jets Key Decision Makers

Based on thorough research of the Winnipeg Jets organization, the following key decision makers have been identified as primary targets for OSF DIGITAL's Salesforce and agentforce implementation proposals:

## 1. Tyler Kurz - Vice President, Business Intelligence

**Role & Responsibilities:**
- Leads data analytics and business intelligence initiatives for True North Sports + Entertainment
- Responsible for developing data-driven strategies to enhance fan engagement and business performance
- Key decision maker for technology platforms related to customer data and analytics
- Oversees the StellarAlgo CDP implementation and utilization

**Background & Expertise:**
- Demonstrated interest in transforming how the Jets connect with fans through data
- Forward-thinking approach to leveraging analytics for business growth
- Likely has technical background combined with business acumen
- Values partnerships that align with the organization's vision for digital transformation

**Pain Points & Priorities:**
- Integrating disparate data sources into a unified view of the fan
- Extracting actionable insights from complex data sets
- Demonstrating ROI from technology investments
- Enhancing the organization's data-driven decision making capabilities

**Decision-Making Influence:**
- Primary influencer for data and analytics technology decisions
- Likely reports to C-suite executives and has significant input on technology strategy
- Probably manages relationships with current technology vendors like StellarAlgo

## 2. Christina Litz - Chief Brand and Commercial Officer

**Role & Responsibilities:**
- Oversees brand strategy, commercial partnerships, and fan experience initiatives
- Responsible for revenue generation through sponsorships and commercial activities
- Key decision maker for fan-facing technologies and experiences
- Manages the Jets' brand positioning and marketing strategy

**Background & Expertise:**
- Extensive experience in sports marketing and brand management
- Forward-thinking approach to fan engagement and experience
- Strong understanding of the commercial aspects of sports business
- Quoted regarding the ProWire implementation, indicating her role in fan experience technology decisions

**Pain Points & Priorities:**
- Creating innovative and memorable fan experiences
- Maximizing revenue from commercial partnerships
- Maintaining brand consistency across all touchpoints
- Demonstrating measurable impact of marketing initiatives

**Decision-Making Influence:**
- Executive-level decision maker with significant budget authority
- Likely has final approval for major brand and commercial technology investments
- Influences technology decisions that impact fan experience and commercial operations

## 3. Dawn Haus - SVP of Culture & Guest Experience

**Role & Responsibilities:**
- Oversees all aspects of the guest experience at Canada Life Centre
- Responsible for venue operations and staff management
- Key decision maker for in-venue technology implementations
- Manages the implementation of guest-facing technologies like the AI security system

**Background & Expertise:**
- Deep understanding of venue operations and guest services
- Focus on creating efficient and enjoyable experiences for fans
- Practical approach to technology implementation with emphasis on measurable results
- Quoted regarding the AI security system implementation, indicating her role in venue technology decisions

**Pain Points & Priorities:**
- Reducing friction points in the guest journey
- Improving operational efficiency while enhancing guest satisfaction
- Managing staffing and training for new technology implementations
- Measuring and demonstrating the impact of guest experience initiatives

**Decision-Making Influence:**
- Senior leadership role with significant influence on venue operations
- Likely has budget authority for guest experience technologies
- Influences technology decisions that impact venue operations and guest experience

## 4. Kevin Donnelly - Senior VP, Venues & Entertainment

**Role & Responsibilities:**
- Oversees all venue operations and entertainment programming
- Responsible for the overall venue strategy and performance
- Key decision maker for major venue infrastructure investments
- Manages relationships with technology vendors for venue systems

**Background & Expertise:**
- Extensive experience in venue management and operations
- Strategic approach to venue technology and infrastructure
- Focus on creating world-class entertainment experiences
- Likely involved in the $2-million sound system upgrade and other venue enhancements

**Pain Points & Priorities:**
- Maximizing venue utilization and revenue
- Ensuring seamless operations during events
- Keeping venue technology current and competitive
- Balancing capital investments with operational needs

**Decision-Making Influence:**
- Executive-level decision maker with significant budget authority
- Likely has final approval for major venue infrastructure investments
- Influences technology decisions that impact venue operations and capabilities

## 5. Mark Chipman - Executive Chairman & Governor

**Role & Responsibilities:**
- Ultimate authority for True North Sports + Entertainment
- Sets overall strategic direction for the organization
- Final approver for major capital investments and strategic initiatives
- Represents the Jets at the NHL Board of Governors

**Background & Expertise:**
- Founder of True North Sports + Entertainment
- Instrumental in bringing the Jets back to Winnipeg
- Strategic visionary with focus on community impact
- Likely takes a hands-on approach to major organizational decisions

**Pain Points & Priorities:**
- Ensuring long-term financial sustainability
- Maintaining competitive advantage in the NHL
- Creating positive community impact
- Building a winning organization both on and off the ice

**Decision-Making Influence:**
- Ultimate decision maker for the organization
- Sets budget parameters and investment priorities
- While may not be involved in day-to-day technology decisions, would approve major strategic initiatives

## Decision-Making Process

The technology decision-making process at the Winnipeg Jets likely follows this pattern:

1. **Identification of Need:** Initial needs likely identified by functional leaders like Tyler Kurz (data), Christina Litz (brand/commercial), or Dawn Haus (guest experience)

2. **Solution Exploration:** Research and vendor evaluation conducted by the respective functional teams

3. **Business Case Development:** ROI analysis and business case created, likely with input from finance team

4. **Executive Review:** Presentation to executive leadership team for review and input

5. **Final Approval:** Depending on investment size, final approval from Mark Chipman for major initiatives

6. **Implementation Planning:** Detailed implementation planning led by the functional owner with IT support

7. **Execution:** Cross-functional implementation with regular executive updates

For a Salesforce and agentforce implementation, Tyler Kurz would likely be the primary champion, with Christina Litz and Dawn Haus as key stakeholders. Kevin Donnelly would be involved for aspects affecting venue operations, and Mark Chipman would provide final approval for the overall investment.
