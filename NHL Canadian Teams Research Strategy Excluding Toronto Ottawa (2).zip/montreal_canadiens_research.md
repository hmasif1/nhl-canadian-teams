# Montreal Canadiens Research

## Basic Information
- Founded: 1909
- Arena: Bell Centre
- Location: Montreal, Quebec
- Team Colors: Red, white, and blue
- Stanley Cup Championships: 24 (most in NHL history)
- Website: https://www.nhl.com/canadiens

## Business Operations & Technology Infrastructure

### Bell Centre Infrastructure
- The Bell Centre is the only professional sports venue in North America to be awarded three independent environmental certifications:
  - LEED Silver for Existing Buildings (EBOM)
  - ISO 14001
  - Quebec's ICI ON RECYCLE Level Three (highest level)
- Centralized operating system for optimizing operations efficiency
- In 2009, the Bell Centre was 35% more efficient in energy savings than any other venue of the same type in North America
- The organization implemented environmentally conscious purchasing policies with 80% of purchases including products that are locally made and/or composed of reused or recycled materials
- All electrical products meet EnergyStar efficiency requirements

### Digital Fan Engagement
- Long-term partnership with FANS Entertainment for mobile entertainment platform
- Mobile application features include:
  - Access to exclusive content
  - Game highlights viewing
  - Food and merchandise ordering from seats
  - Interactive games
  - Social media integration
  - Friend location services within the Bell Centre
- Implementation of public Wi-Fi throughout the Bell Centre
- Mobile platform available for iOS and Android users
- Reaches over 875,000 fans annually at the Bell Centre

### Analytics Department
- In 2022, hired Christopher Boucher as director of a new analytics department
- Building robust data infrastructure requiring data engineers
- Focus on taking a system-wide approach to analytics

### Management Structure
- Key Leadership:
  - Kent Hughes - General Manager
  - John Sedgwick - Assistant General Manager
  - Kevin Gilmore - Chief Operating Officer (as of 2014)
  - Xavier Luydlin - Director of Building Operations

## Business Opportunities for OSF DIGITAL

### CRM and Fan Engagement Enhancement
- Current mobile platform could benefit from integration with Salesforce CRM to create a unified customer view
- Opportunity to enhance personalization capabilities through Salesforce Marketing Cloud
- Potential to implement AI-driven fan engagement strategies

### Data Analytics Infrastructure
- Opportunity to enhance their analytics department with Salesforce Einstein Analytics
- Need for robust data integration between various systems (ticketing, merchandise, concessions, etc.)
- Potential for predictive analytics to improve fan retention and revenue generation

### E-commerce and Merchandising
- Current mobile ordering system could be enhanced with Salesforce Commerce Cloud
- Opportunity to create a seamless omnichannel experience across in-arena, online, and mobile shopping

### Sustainability Reporting and Management
- Potential to implement Salesforce Net Zero Cloud to track and manage their sustainability initiatives
- Opportunity to enhance reporting capabilities for their environmental certifications

### Operational Efficiency
- Opportunity to streamline operations with Salesforce Service Cloud
- Potential to implement agentforce solutions for internal communications and staff management

## Key Decision Makers to Target
- Kent Hughes - General Manager
- John Sedgwick - Assistant General Manager
- Director of IT/Digital (to be identified)
- Director of Fan Experience (to be identified)
- Christopher Boucher - Director of Analytics
- Xavier Luydlin - Director of Building Operations
