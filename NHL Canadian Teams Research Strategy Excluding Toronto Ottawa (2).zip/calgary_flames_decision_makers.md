# Calgary Flames Key Decision Makers for Salesforce & Agentforce Implementation

## Executive Leadership

### Robert Hayes
**Title:** President & CEO, Calgary Sports and Entertainment Corporation (CSEC)
**Role:** Ultimate business decision maker with final approval authority for major technology investments
**Focus Areas:** Overall business strategy, revenue growth, operational efficiency
**Background:** Recently appointed (May 2024) to lead CSEC, replacing John Bean
**Influence Level:** Executive Sponsor (High)

### John Bean
**Title:** Vice Chairman, CSEC (former President & CEO)
**Role:** Senior advisor with significant influence on strategic decisions
**Focus Areas:** Strategic initiatives, business continuity, stakeholder relationships
**Background:** Former CEO with deep knowledge of the organization's operations and strategy
**Influence Level:** Strategic Advisor (Medium-High)

### Lorenzo DeCicco
**Title:** Chief Operating Officer, CSEC
**Role:** Oversees day-to-day operations and implementation of strategic initiatives
**Focus Areas:** Operational efficiency, business process optimization, revenue generation
**Background:** Described as an "Innovative Executive with strong business development acumen and Fortune 500 experience"
**Influence Level:** Operational Decision Maker (High)

### Paul Kong
**Title:** Chief Financial Officer, CSEC
**Role:** Financial decision maker responsible for budget approval and ROI assessment
**Focus Areas:** Investment returns, cost management, financial performance
**Background:** Oversees financial operations for CSEC
**Influence Level:** Financial Approver (High)

## Technology & Operations Leadership

### Ziad Mehio
**Title:** VP of Technology and Food & Beverage, CSEC
**Role:** Primary technology decision maker responsible for technology strategy and implementation
**Focus Areas:** Technology infrastructure, digital transformation, vendor selection, food & beverage operations
**Background:** Led implementation of Amazon's Just Walk Out technology and other digital initiatives
**Influence Level:** Technical Decision Maker (High)

### Susie Darrington
**Title:** VP of Building Operations, CSEC; Scotia Place Project Committee Member
**Role:** Responsible for arena operations and technology implementation in physical spaces
**Focus Areas:** Arena technology, fan experience, facility management, Scotia Place transition
**Background:** Involved in planning for Scotia Place, with focus on operational improvements over Saddledome
**Influence Level:** Operational Stakeholder (Medium-High)

### Bob Hunter
**Title:** Project Director, Scotia Place
**Role:** Oversees the development and implementation of the new arena project
**Focus Areas:** Arena construction, technology integration, project management
**Background:** Leading the Scotia Place development project through 2027 completion
**Influence Level:** Project Stakeholder (Medium)

## Business Operations Leadership

### [VP of Marketing / Fan Experience]
**Note:** Research did not reveal a specific marketing leader by name, but this role likely exists
**Role:** Responsible for marketing strategy and fan experience initiatives
**Focus Areas:** Fan engagement, brand management, digital marketing
**Influence Level:** Marketing Stakeholder (Medium-High)

### [Director of Digital]
**Note:** Research did not reveal a specific digital leader by name, but this role likely exists given the FanReach app implementation
**Role:** Responsible for digital products and platforms
**Focus Areas:** Mobile app, website, digital content, fan engagement
**Influence Level:** Digital Stakeholder (Medium)

## Target Decision Makers for Salesforce & Agentforce Implementation

Based on the research, the following individuals should be prioritized for personalized outreach regarding Salesforce and agentforce implementations:

### Primary Targets

1. **Robert Hayes (President & CEO, CSEC)**
   - Executive sponsor with ultimate decision-making authority
   - Focus messaging on business impact, revenue growth, and competitive advantage
   - Emphasize Scotia Place transition as a catalyst for digital transformation

2. **Ziad Mehio (VP of Technology and Food & Beverage, CSEC)**
   - Primary technical decision maker
   - Focus messaging on technical capabilities, integration with existing systems (FanReach, Amazon Just Walk Out), and implementation approach
   - Highlight data security integration with existing Acronis partnership

3. **Lorenzo DeCicco (COO, CSEC)**
   - Key operational decision maker
   - Focus messaging on operational efficiency, process improvement, and customer experience
   - Emphasize seamless transition to Scotia Place operations

### Secondary Targets

4. **Paul Kong (CFO, CSEC)**
   - Financial approver
   - Focus messaging on ROI, cost savings, and financial benefits
   - Highlight phased implementation approach to manage investment

5. **Susie Darrington (VP of Building Operations, CSEC)**
   - Arena operations stakeholder
   - Focus messaging on enhancing in-arena experience and Scotia Place transition
   - Emphasize integration with physical venue operations

6. **John Bean (Vice Chairman, CSEC)**
   - Strategic advisor
   - Focus messaging on long-term strategic value and competitive positioning
   - Highlight industry trends and best practices

### Decision-Making Dynamics

The decision-making process for a major technology implementation like Salesforce and agentforce would likely follow this path:

1. **Initial Interest:** Generated through outreach to technical stakeholders like Ziad Mehio
2. **Technical Evaluation:** Led by Ziad Mehio with input from digital and marketing teams
3. **Operational Assessment:** Involving Lorenzo DeCicco and Susie Darrington
4. **Business Case Development:** Involving Paul Kong and Lorenzo DeCicco
5. **Final Approval:** Ultimate decision made by Robert Hayes as CEO, with input from John Bean

A successful engagement strategy should target multiple stakeholders simultaneously, recognizing their different priorities and concerns while presenting a unified vision for how Salesforce and agentforce can transform the Flames' digital capabilities and support their transition to Scotia Place in 2027.
