# Vancouver Canucks Key Decision Makers

## Executive Leadership

### Michael Doyle
**Title:** President, Canucks Sports & Entertainment - Business Operations
**LinkedIn:** https://ca.linkedin.com/in/michael-doyle-7b24091
**Background:** Leads all business operations for Canucks Sports & Entertainment, including Rogers Arena operations, fan experience, and business strategy. Previously announced partnerships with DP World and has been in the role since August 2021.
**Influence Area:** Overall business strategy, major partnership decisions, and executive approval for significant technology investments.

### Nguyen Nguyen
**Title:** Sr. Vice President of Technology, Canucks Sports & Entertainment
**LinkedIn:** https://ca.linkedin.com/in/nguyen-nguyen-81a86850
**Background:** A forward-thinking technology leader responsible for the organization's technology infrastructure and digital strategy. Oversees all technology implementations and digital transformation initiatives.
**Influence Area:** Technology infrastructure, digital transformation, IT operations, and technology vendor relationships.

## Digital & Marketing Leadership

### John Delaney
**Title:** Director, Digital, Canucks Sports & Entertainment
**LinkedIn:** https://ca.linkedin.com/in/thejohnallan
**Background:** Leads the digital team responsible for strategy and management of digital properties across Vancouver Canucks (NHL), Abbotsford Canucks (AHL), and other CSE properties. Recently hiring for digital marketing roles, indicating team expansion.
**Influence Area:** Digital strategy, mobile app, email marketing, paid media, social media, and digital content.

### [Current VP of Marketing]
**Note:** Kevin Kinghorn previously served as VP of Marketing but has since moved to the Portland Trail Blazers as Executive Vice President & Chief Marketing Officer. Research did not reveal his current replacement.
**Influence Area:** Marketing strategy, brand management, fan engagement, and marketing technology.

## Revenue & Commercial Leadership

### [Current Chief Revenue Officer]
**Note:** Terry Kalna previously served as Chief Revenue Officer but announced his departure in August 2024 to join USA Hockey. Research did not reveal his current replacement.
**Influence Area:** Revenue generation, sponsorships, ticket sales, and commercial partnerships.

## Ownership

### Francesco Aquilini
**Title:** Chairman & Governor, NHL
**Background:** Part of the ownership family of Canucks Sports & Entertainment, with ultimate decision-making authority for major organizational investments.
**Influence Area:** Final approval on major capital expenditures and strategic direction.

### Roberto Aquilini
**Title:** Alternate Governor, NHL
**Influence Area:** Ownership decisions and strategic direction.

### Paolo Aquilini
**Title:** Alternate Governor, NHL
**Influence Area:** Ownership decisions and strategic direction.

## Target Decision Makers for Salesforce & Agentforce Implementation

Based on the research, the following individuals should be prioritized for personalized outreach regarding Salesforce and agentforce implementations:

1. **Nguyen Nguyen** - As SVP of Technology, he would be the primary technical decision maker for any major technology implementation.

2. **John Delaney** - As Director of Digital, he would be a key influencer and potential day-to-day leader for digital transformation initiatives.

3. **Michael Doyle** - As President of Business Operations, he would be the executive sponsor and ultimate business decision maker.

These three individuals represent the technical decision maker, the operational implementer, and the executive sponsor - covering all key aspects of the decision-making process for a major technology implementation.
