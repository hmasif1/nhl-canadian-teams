# Edmonton Oilers Research

## Basic Information
- Founded: 1972 (joined NHL in 1979)
- Arena: Rogers Place
- Location: Edmonton, Alberta
- Team Colors: Orange, navy blue, and white
- Stanley Cup Championships: 5 (1984, 1985, 1987, 1988, 1990)
- Website: https://www.nhl.com/oilers

## Business Operations & Technology Infrastructure

### Leadership Structure
- Key Leadership:
  - Daryl Katz - Owner, Chairman, Governor, OEG Inc.
  - Jürgen Schreiber - CEO, Business Operations, OEG Inc.
  - Stew MacDonald - President & Chief Revenue Officer, OEGSE
  - Stuart Ballantyne - President & Chief Operating Officer, OEGSE
  - Ryan Hyrcun - Manager of Video Production

### Rogers Place Technology Infrastructure
- Over 1,200 TV screens throughout the venue, including game coverage in all suites, clubs and concourses
- Wi-Fi access in all clubs, concourses and seating bowl
- The largest true high-definition center ice scoreboard in the NHL
- Interactive Rogers Place App that enhances guest experience
- Video Production Control Room on the venue's event level
- State-of-the-art broadcast technology, facilities and capabilities
- LEED Silver certified arena
- Phone charging stations throughout the venue

### Digital Fan Engagement
- Oilers+ streaming platform that gives fans exclusive access to:
  - Behind-the-scenes content
  - Live shows
  - Pre/post-game shows
  - Press conferences
- Subscription-based model that grew from 10K to 20K subscribers in two years
- Generated over $1M in revenue in the second year
- LiveU technology for mobile live streaming capabilities
- Ability to produce content from various locations, including special events like the NHL Heritage Classic

### ICE District Development
- Rogers Place is part of the larger ICE District development
- ICE District Phase I has generated $3.2 billion in economic impact for Edmonton
- Total project cost of $613.7 million, including arena, Winter Garden (Ford Hall), Downtown Community Arena, and LRT connection

## Business Opportunities for OSF DIGITAL

### CRM and Fan Engagement Enhancement
- Opportunity to enhance the Oilers+ streaming platform with Salesforce integration
- Potential to implement AI-driven content recommendations based on viewing habits
- Opportunity to create a unified fan profile across ticketing, merchandise, and streaming platforms

### Digital Content Management
- Potential to implement Salesforce Marketing Cloud for content distribution and analytics
- Opportunity to enhance video production workflows with agentforce solutions
- Potential to integrate LiveU technology with Salesforce for seamless content management

### Arena Technology Integration
- Opportunity to connect the 1,200+ TV screens with Salesforce CRM for personalized messaging
- Potential to enhance the Rogers Place App with Salesforce Mobile SDK
- Opportunity to implement Salesforce Service Cloud for arena operations management

### Data Analytics and Fan Insights
- Opportunity to implement Salesforce Einstein Analytics to derive insights from streaming platform data
- Potential to create predictive models for content preferences and subscription renewals
- Opportunity to enhance revenue generation through targeted promotions

### E-commerce and Merchandising
- Potential to implement Salesforce Commerce Cloud for merchandise sales
- Opportunity to create personalized merchandise recommendations based on content preferences
- Potential to implement omnichannel shopping experiences across in-arena, online, and mobile platforms

## Key Decision Makers to Target
- Daryl Katz - Owner, Chairman, Governor, OEG Inc.
- Jürgen Schreiber - CEO, Business Operations, OEG Inc.
- Stew MacDonald - President & Chief Revenue Officer, OEGSE
- Stuart Ballantyne - President & Chief Operating Officer, OEGSE
- Ryan Hyrcun - Manager of Video Production
- Director of IT/Digital (to be identified)
- Director of Fan Experience (to be identified)
