# Presentation: OSF DIGITAL NHL Canadian Teams Prospecting Strategy

## Executive Summary

- Comprehensive analysis of 5 Canadian NHL teams (excluding Toronto and Ottawa)
- Identified team-specific business opportunities for OSF DIGITAL solutions
- Developed tailored prospecting strategies with ROI models
- Created personalized outreach approaches for key decision-makers

## Canadian NHL Teams Overview

### Winnipeg Jets
- **Current Standing**: 1st in Central Division (106 points)
- **Key Technology**: StellarAlgo CDP, Jets 360 Rewards Program
- **Priority**: HIGH

### Edmonton Oilers
- **Current Standing**: 3rd in Pacific Division (89 points)
- **Key Technology**: LiveU content creation, Rogers Place infrastructure
- **Priority**: HIGH

### Montreal Canadiens
- **Current Standing**: Wild Card position (77 points)
- **Key Technology**: Fans Entertainment partnership, bilingual requirements
- **Priority**: MEDIUM-HIGH

### Vancouver Canucks
- **Current Standing**: Wild Card contention (81 points)
- **Key Technology**: Fortinet, Creative Realities digital signage
- **Priority**: MEDIUM

### Calgary Flames
- **Current Standing**: Wild Card contention (80 points)
- **Key Technology**: FanReach app, new arena development (2027-28)
- **Priority**: MEDIUM-LOW

## Key Business Opportunities

### Winnipeg Jets
1. Salesforce Marketing Cloud integration with StellarAlgo CDP
2. Jets 360 Rewards Program enhancement with Experience Cloud
3. Agentforce implementation for customer service

### Edmonton Oilers
1. Digital Fan Experience Transformation with Experience Cloud
2. Marketing Cloud for player-driven campaigns (McDavid, Draisaitl)
3. Commerce Cloud for premium experience sales

### Montreal Canadiens
1. Bilingual Fan Engagement Platform with Experience Cloud
2. Heritage-Focused Digital Asset Management with Salesforce CMS
3. Service Cloud for enhanced fan services

### Vancouver Canucks
1. Integrated Digital Signage and Commerce Platform
2. Enhanced Fan Feedback System with Service Cloud
3. Marketing Cloud Personalization for tech-savvy market

### Calgary Flames
1. New Arena Digital Strategy Consulting for Scotia Place
2. Mobile App Enhancement with Experience Cloud
3. Marketing Cloud for season ticket retention during arena transition

## Prospecting Strategy

### Prioritization
1. Winnipeg Jets - playoff team with proven tech investment
2. Edmonton Oilers - star power and sophisticated arena
3. Montreal Canadiens - market size and heritage brand
4. Vancouver Canucks - tech-savvy market and digital investments
5. Calgary Flames - focus on long-term arena planning

### Implementation Timeline
- **Phase 1**: Initial Outreach (Months 1-2)
- **Phase 2**: Solution Development (Months 2-4)
- **Phase 3**: Pilot Projects (Months 4-8)
- **Phase 4**: Expansion (Months 8-12)

## ROI Models

### Winnipeg Jets
- 15-20% increase in fan engagement metrics
- 10-15% increase in digital revenue streams
- Payback period: 12-18 months

### Edmonton Oilers
- 20-25% increase in digital engagement
- 30% improvement in sponsor activation metrics
- Payback period: 14-20 months

### Montreal Canadiens
- 20% increase in digital engagement
- New revenue streams from content monetization
- Payback period: 16-22 months

### Vancouver Canucks
- 25% increase in in-arena purchases
- 30% improvement in fan satisfaction metrics
- Payback period: 14-18 months

### Calgary Flames
- Long-term cost savings from proper planning
- 35% increase in mobile app engagement
- Payback period: 18-24 months

## Key Decision Makers

### Winnipeg Jets
- Tyler Kurz, VP Business Intelligence
- Andrew Wilkinson, Director of Digital Strategy
- Mark Chipman, Executive Chairman & Governor

### Edmonton Oilers
- OEG Digital Strategy Director (to be identified)
- VP Marketing (to be identified)
- Tom Anselmi, President of Business Operations

### Montreal Canadiens
- VP Digital Strategy (to be identified)
- Director of Fan Experience (to be identified)
- France Margaret Bélanger, President, Sports and Entertainment

### Vancouver Canucks
- Director of Technology (to be identified)
- VP Fan Experience (to be identified)
- Michael Doyle, President, Business Operations

### Calgary Flames
- Arena Development Technology Lead (to be identified)
- Director of Digital Strategy (to be identified)
- John Bean, President & CEO

## Next Steps

1. Finalize personalized outreach materials
2. Establish LinkedIn connections with key decision makers
3. Schedule initial discovery meetings with priority teams
4. Develop detailed solution proposals based on feedback

## Thank You

OSF DIGITAL
Transforming fan experiences through Salesforce and agentforce solutions
